package com.shopforhome.shopforhomes.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.shopforhome.shopforhomes.Dao.ProductDao;
import com.shopforhome.shopforhomes.Entities.ProductsEntity;
import java.util.List;

@Service
public class ProductServices {

    @Autowired
    private ProductDao productDao;

    // Get all products
    public ResponseEntity<List<ProductsEntity>> getAllProducts() {
        List<ProductsEntity> products = productDao.findAll();
        if (products.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    // Add a new product
    public ResponseEntity<ProductsEntity> addProduct(ProductsEntity product) {
        ProductsEntity savedProduct = productDao.save(product);
        return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
    }

    public ResponseEntity<ProductsEntity> getProduct(String pid) {
        ProductsEntity product = productDao.findById(pid).orElse(new ProductsEntity());
        return new ResponseEntity<>(product, HttpStatus.OK);
    }

    // public List<String> autocomplete(String query){
    //     return productDao.autocomplete(query);
    // }

    public List<ProductsEntity> searchProducts(String query){
        return productDao.searchProducts(query);
    }
}
