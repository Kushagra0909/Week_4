package com.shopforhome.shopforhomes.Entities;

public enum OrderStatus {
    PENDING,
    COMPLETED,
    CANCELED
}
